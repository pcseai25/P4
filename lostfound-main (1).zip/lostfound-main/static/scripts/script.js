const myDiv = document.getElementById("hero");
myDiv.scrollTo(0, 1000);
console.log("hello world");
